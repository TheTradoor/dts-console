# Version 0.3.3 validation

Paper overview, illustrative code animation and decorative point landscape.
Application, protocol, cryptography and Squads modules are unchanged.

[Browser run 41835377223](https://github.com/TheTradoor/dts-console/actions/runs/41835377223)
passed **34/34** cases at 1440 × 1000 and 390 × 844, without skips, retries or
flaky outcomes. Motion checks compare rendered canvas pixels before and after
pause/resume, require a still canvas under reduced motion and after leaving the
overview, and verify that navigation preserves the reviewed transaction session.

All 44 screenshot layouts were reviewed. Forty-two final images are byte-identical
to the preceding visual review; both changed landscape images were rechecked.
The mobile landscape was moved below its copy and controls. Enlarged mobile
captures also confirmed readable addresses, signatures, errors and draft export
controls. Capture waits for finite entrance animations and notifications to finish.
This is a visual review, not a WCAG or independent security audit.

Thirty-four diagnostics contain no uncaught JavaScript errors, unexpected external
requests or failed application requests. Sixteen served asset hashes match the
source; external fonts were disabled. Four Squads downloads match a separately
constructed and validated draft, two session exports match the fixture and four
verification reports match their source fixtures.

The clean CI checkout `850e12e360c59f7e316216e0022b5d4a53b3c563` has the same tree
as head `ddf83fb05faa57fb7d3f9dd32fce9727e2c601fd`. The downloaded artifact passed
ZIP integrity and SHA-256 checks. Exact source, artifact and image hashes are in
[motion-validation.json](evidence/motion-validation.json) and
[motion-screenshots.json](evidence/motion-screenshots.json). The archive expires
on November 18; the manifests are records, not copies of the screenshots.

[Squads compatibility](https://github.com/TheTradoor/dts-console/actions/runs/41835377756)
and [firmware reproduction](https://github.com/TheTradoor/dts-console/actions/runs/41835377575)
also passed for this code commit. An intermediate browser run caught one desktop
resume failure. Resuming now reconciles the current section bounds and starts a
fresh animation frame loop; the complete passing run above includes that fix.

Mobile coverage is Chromium viewport emulation, not Safari or physical phones.
No wallet, live-key signing, RPC, broadcast or local-validator execution was added
or tested. Earlier records below describe historical interfaces.

# Version 0.3.2 validation

Monochrome overview and workspace with a labelled process schematic. Application
logic, protocol, cryptography and Squads draft semantics are unchanged.

[Browser run 41826198655](https://github.com/TheTradoor/dts-console/actions/runs/41826198655)
passed **30/30** cases at 1440 × 1000 and 390 × 844, without skips, retries or
flaky outcomes. All 40 screenshot states were visually reviewed, including
successful verification, rejection, stale-state locks and unsigned draft export.
Controls and full-address review fields remain readable without blocking overlap
or horizontal document overflow. Errors and status use text and symbols as well
as contrast. The interface color literals are neutral; mint glows are removed.

Thirty diagnostics contain zero uncaught JavaScript errors, unexpected external
requests or failed application requests. Fourteen served asset hashes match the
source. External fonts were disabled. Four Squads downloads match the independently
validated draft, two session exports match the fixture and four verification
reports match their source fixtures. Syntax, unique HTML IDs and label targets
passed. Direct Chrome checks also confirmed overview entry, recorded fixture
verification and zero-amount rejection with the previous review cleared.

The clean CI checkout `6c7991f1e176557ac6230854e8156b744f24af6a` has the same tree
as head `453243c9473a9a8e060d739e5254571d2f218c8c`. The downloaded evidence ZIP
passed integrity and SHA-256 checks. Exact source, artifact and screenshot hashes
are in [monochrome-validation.json](evidence/monochrome-validation.json) and
[monochrome-screenshots.json](evidence/monochrome-screenshots.json). The archive
expires on November 18; these manifests are not copies of the screenshots.

[Squads compatibility](https://github.com/TheTradoor/dts-console/actions/runs/41826198566)
and [firmware reproduction](https://github.com/TheTradoor/dts-console/actions/runs/41826198581)
also passed for this code commit.

Mobile results use Chromium viewport emulation, not Safari or physical phones.
This is not a WCAG or independent security audit. Wallet connection, live-key
signing, broadcast and local-validator execution remain outside this validation.

# Version 0.3.1 validation

Dark overview and workspace redesign; the signing bridge, codec, cryptographic
verification and Squads draft semantics are unchanged.

[Browser run 41823605049](https://github.com/TheTradoor/dts-console/actions/runs/41823605049)
passed **30/30** cases at 1440 × 1000 and 390 × 844, without skips, retries or
flaky outcomes. Coverage includes overview/workflow entry points, direct links,
browser history with session preservation and keyboard skip-link focus, plus
all existing fixture and Squads import, export, verification and rejection cases.

All 40 screenshot states were reviewed. The first run's 40 captures were
inspected; the final run retained 15 byte-identical images and all 25 changed
captures were rechecked. Controls, full-address review fields and error states
remain readable, without blocking overlap or horizontal document overflow.
Thirty diagnostics contain zero uncaught JavaScript errors, unexpected external
requests or failed application requests. Fourteen served asset hashes match the
source. External fonts were disabled. Four Squads downloads match the independently
validated draft, two session exports match the fixture and four verification
reports match their source fixtures.

The clean CI checkout `86103953bdd2abe51c78c33857caf5da9527c949` has the same tree
as head `0287adabc1814e07aa2c73a4144cde1293b30df5`. The downloaded evidence ZIP
passed integrity and SHA-256 checks. Exact source, artifact and image hashes are
recorded in [redesign-validation.json](evidence/redesign-validation.json) and
[redesign-screenshots.json](evidence/redesign-screenshots.json). The archive expires
on November 18; these manifests are not copies of the images.

[Squads run 41823605201](https://github.com/TheTradoor/dts-console/actions/runs/41823605201)
passed 29 tests, including 128 SDK differential vectors.
[Firmware run 41823605039](https://github.com/TheTradoor/dts-console/actions/runs/41823605039)
passed 51 firmware/host tests, 5,803 differential vectors, every u16 length and
four full signing reproductions. Syntax and HTML ID/label checks also passed.
Direct Chrome checks confirmed overview, preparation, review, actual recorded
signature verification, unsigned Squads preparation and keyboard navigation.

An intermediate [run 41823440060](https://github.com/TheTradoor/dts-console/actions/runs/41823440060)
passed 28 cases and failed two new keyboard assertions: the test expected heading
focus although the skip link intentionally focuses main content. The assertion
was corrected before the complete successful run above.

Mobile results use Chromium viewport emulation, not Safari or physical phones.
This is not a WCAG or independent security audit. Wallet connection, live-key
signing, broadcast and local-validator execution remain outside this validation.

# Version 0.3.0 validation

[Browser CI run 41816685541](https://github.com/TheTradoor/dts-console/actions/runs/41816685541)
passed **26/26** cases: thirteen scenarios at 1440 × 1000 and at 390 × 844,
with no skips, retries or flaky outcomes. All 38 full-page screenshots were
visually inspected. Review fields, addresses, instructions, errors and controls
were readable without blocking clipping or overlap. Mobile is Chromium viewport
emulation; this is not Safari, a device lab or a WCAG audit.

All 26 diagnostics had zero uncaught JavaScript errors, unexpected external
requests and failed application requests. Thirteen served asset hashes matched
the source. External fonts were disabled. The four downloaded Squads JSON files
matched the independently validated draft; both fixture session exports matched
exactly and four downloaded verification reports matched their source fixtures.

The run tested head `ac0259d35d14f7f773586eaf39627eaef772b8c8` through synthetic
merge `914adef1a5559e5089a09b4f070084000cb2bff4`; both use Git tree
`f9c7a31d066c27c0dc26d24a04f138434d3de8c9`. Checkout was clean. The downloaded
artifact passed ZIP integrity checks and matched GitHub's SHA-256. Exact source
hashes, artifact metadata and scope are in [squads-validation.json](evidence/squads-validation.json),
and all image hashes/dimensions are in [squads-screenshots.json](evidence/squads-screenshots.json).
The archive expires on 2026-11-18; the manifests are permanent records, not image copies.

[Squads compatibility](https://github.com/TheTradoor/dts-console/actions/runs/41816685483)
passed 29 tests, including 128 deterministic byte/PDA comparisons with the pinned
SDK and rejection of all 487 truncated prefixes. The combined local JavaScript
suite passed 59 tests with DTS_UPSTREAM set.
[Firmware CI](https://github.com/TheTradoor/dts-console/actions/runs/41816685248)
passed its 51 firmware/host tests, 5,803 differential vectors, all 65,536 u16
lengths and four signing reproductions. The 51 and 59 totals overlap on the
original 30 JavaScript fixture tests; they must not be added together.

Direct Chrome preview checks confirmed draft construction, actual downloaded
export validation, stale-index locking even after reverting values, zero-amount
rejection and the software-only readiness view. These checks supplement CI.

No local-validator execution has been performed. Squads signing and on-chain
approval remain unimplemented; account state and manual comparisons are unverified.

The detailed records below describe the earlier 0.2.0 baseline. Its screenshot
hashes do not attest the changed 0.3.0 interface.

# Validation record

## Automated — 0.2.0

The clean-source run on 2026-11-04 passed 30 JavaScript tests and 21 Python
tests, with no failures or skips. Four complete firmware outputs and evidence
objects reproduced. See [the report](../dist/validation.json) and
[JavaScript TAP output](evidence/validation.tap).

The experimental parser matched both host decoders on 5,803 deterministic
vectors (1,805 accepted, 3,998 rejected). All 65,536 u16 declared lengths were
exercised separately. Selected paths also ran on the Python CPU core with bus
and stack tracing. Parser resources: 418 ROM bytes, 11 scratch bytes and two
stack bytes for the parser call; this is not a whole-firmware stack bound.

Correctly CRC-sealed unsupported messages were injected directly into the
emulator to bypass host validation and test the pre-sign gate. Other checks
cover unknown profiles, expected-key substitutions, input-envelope changes
after freezing, all invalid latch states and a blocked write to a locked bank.
See [FIRMWARE_POLICY.md](FIRMWARE_POLICY.md) for the precise scope.

Both fixture-result.json and nonce-fixture-result.json were generated by
executing the pinned 65C02 firmware on the upstream C emulator. The bridge
checked both bank locks, zero blocked writes, an unchanged frozen message, a
cleared emulated scratch region, the complete output record, an identical
OpenSSL signature, and successful OpenSSL verification.

The opt-in builds produce policy-fixture-result.json and
policy-nonce-fixture-result.json. Their 256-byte signed records match the
baseline byte for byte. Emulated cycles for these fixtures:

| Build | Legacy | Durable nonce |
| --- | --- | --- |
| Unmodified pinned ROM | 651,345,707 | 652,476,175 |
| Experimental parser ROM | 651,354,174 | 652,488,289 |

These cycle differences include changed code placement as well as parsing.
They are not physical signing times or general worst-case timing bounds.

These checks do not establish physical erasure, hardware isolation, side-channel
resistance, trusted device authorization, or successful on-chain execution.

## Browser status — 0.2.0

Browser acceptance is complete for the recorded public-fixture scope.
[Browser CI run 41810704326](https://github.com/TheTradoor/dts-console/actions/runs/41810704326)
passed all 18 cases for head `a84b34be157c7b8e611aff267bafdceac6b46ae5`.
GitHub tested synthetic merge `9a1034092a3396b7c59c2a6b688dcc6d2a4f6c8e`;
its Git tree equals the head's tree. The checkout was clean. The run used
Chromium 156.0.8078.4 on Ubuntu 24.04, nine scenarios at 1440 × 1000 and the same
nine at 390 × 844, with zero failures, skips, flaky results or retries.

The runner compared eleven application/fixture asset hashes with the checkout
before each scenario. Inspection of all eighteen diagnostic attachments found
no uncaught application errors, unexpected external requests or failed
application requests. External fonts were disabled for this run.

The cases cover readiness and all four views; session file imports and signed
result verification for both fixtures; downloaded reports; cross-session and
modified-record rejection; all recipient pages and acknowledgement before
export; input-edit invalidation; malformed replacement sessions; and malformed
result JSON. Malformed results show REJECTED and clear the previous report.
The four downloaded verification reports were separately compared with their
source fixtures; both exported sessions matched the legacy fixture exactly.

All **28 full-page PNGs** in the archive were visually inspected on 2026-11-04:
14 desktop and 14 mobile captures. Review fields, signatures, status labels,
error messages and controls were readable without persistent overlap or
clipping in these captures. Long hashes/signatures wrapped within their cards
on mobile. The horizontal-overflow assertions also passed. This inspection is
not a WCAG audit or a claim about untested browser/device combinations.

The preceding run's screenshots included transient import/export notifications
covering some text. Capture now waits for the real five-second notification to
expire, with a ten-second assertion deadline; it does not hide content or alter
the page. Screenshots were also added to the three existing damaged/malformed
input scenarios. The rerun above includes those changes; application code is
unchanged by this capture correction.

The downloaded archive passed ZIP integrity checks and matched GitHub's SHA-256
`e92664534687c20ac65a73d433dd57ac20306cb01a48680175588ea70e2e0908`.
Artifact ID **13312955051**, size 9,259,871 bytes, expires **2026-11-18**.
The [screenshot manifest](evidence/browser-screenshots.json) records each
archive path, dimensions, SHA-256 and review outcome. The workflow retains
archives for fourteen days; the manifest is a record, not a permanent image copy.
See also [the machine-readable validation record](evidence/browser-validation.json).

[The firmware run for the same head](https://github.com/TheTradoor/dts-console/actions/runs/41810704362)
also passed. The previously recorded local clean-fetch reproduction passed all
51 firmware/host tests, 5,803 differential vectors, all 65,536 u16 lengths and
four signing runs. Browser cases are separate from those 51 tests.

Direct Chrome preview checks exercised actual file pickers, both fixture
signatures, both downloaded JSON reports, review-gated export, changed amounts,
modified records and malformed imports. The exported session matched the
fixture exactly; both reports matched the source message hashes, signature and
review fields, retained the trusted-device limitation, and did not copy unsigned
firmware evidence into security claims. Desktop rendering was inspected, as were
Prepare, Readiness and a verified result in a 390 × 844 CSS iframe. Its content
and scroll widths were both 375 pixels (390 including the scrollbar). This is
distinct from CI mobile viewport emulation.

An authenticated smoke check of the private published Site on 2026-11-04 loaded
v0.2.0 and verified the recorded firmware example. Importing malformed result
JSON changed VERIFIED to REJECTED and removed the prior report; verifying the
example again restored VERIFIED. Readiness showed 51 passed and M1 partial.
No app-origin console errors were observed. This was a targeted live smoke
check, not a second execution of the full CI suite against production.

These results cover public fixture workflows. They do not establish physical
hardware safety, trusted device approval, Safari behavior, or live-chain/Squads
execution. The firmware parser PR still retains the original 0.1.1 browser files.

## Historical browser checks — 0.1.0 interface

Completed in Chrome on the original 0.1.0 interface through the actual UI.
The 0.1.1 changes concern source pins, Python boundary validation, packaging
and documentation; these historical browser checks are not a new hardware test:

- Prepare the default 5,000-lamport fixture and decode all fields.
- Confirm export is disabled until all four recipient pages are visited and
  the user acknowledgement is checked.
- Verify the recorded 65C02 result in the browser.
- Change the amount to 6,000 lamports and confirm the old result is rejected
  as belonging to a different session.
- Review and export that new session through the browser download flow.
- Execute it with the actual pinned 65C02 firmware: 650,669,743 cycles,
  double-sign/verify retained, OpenSSL signature equality and verification.
- Import the downloaded session and fresh result through browser file pickers;
  the result visibly verified for exactly 6,000 lamports.
- Import a result with a modified signature byte; the browser rejected its CRC.
  Automated tests also reject a modified signature after its CRC is recomputed.
- Inspect the desktop layout and a real 390-by-844 CSS iframe viewport.
  Mobile document width and scroll width both measured 375 CSS pixels
  (390 pixels including the scrollbar), with no horizontal overflow.

The local preview uses HTTP. Portable verification was added because WebCrypto
is unavailable in that context; automated tests cross-check the portable
implementation against the platform provider, including a no-WebCrypto case.

The original JavaScript run passed 28 tests. The current recorded validation
includes the independent Python suite and four fresh full firmware executions;
use ../dist/validation.json for its actual counts and timestamp.
Manual browser checks and historical upstream tests are not added to that count.

## Source-pin correction in 0.1.1

The earlier preparation copy appended one newline to each of the eight source
files. Its hashes therefore did not match a clean upstream download. The source
lock now hashes the exact raw bytes, verified against GitHub Git blob IDs at
the pinned commit. No upstream executable statement was changed. Both recorded
firmware outputs must reproduce unchanged after this correction.

The Python host validator also now rejects boolean false as profile 0 rather
than relying on Python's equality between false and numeric zero.

The clean-fetch check also exposed four missing transitive imports: the
assembler imports cpu65c02, which imports timing, engine and parts. All four
are now fetched and pinned, making the manifest cover twelve source files.
Reproduction uses only this downloaded source closure.
